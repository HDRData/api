-- --------------------------------------------------------

--
-- Setup of the API's base tables
--
-- Nathanael Tombs
-- 2/14/2015
-- 10:21 PM
--


-- --------------------------------------------------------

--
-- Table structure for table `country_name`
--

CREATE TABLE IF NOT EXISTS `country_name` (
  `code` varchar(3) NOT NULL,
  `language` varchar(2) NOT NULL,
  `name` varchar(60) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`code`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `indicator_name`
--

CREATE TABLE IF NOT EXISTS `indicator_name` (
  `id` mediumint(8) unsigned NOT NULL,
  `language` varchar(2) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `indicator_value`
--

CREATE TABLE IF NOT EXISTS `indicator_value` (
  `country_code` varchar(3) NOT NULL,
  `indicator_id` mediumint(8) unsigned NOT NULL,
  `year` smallint(6) unsigned NOT NULL,
  `value` double NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`country_code`,`indicator_id`,`year`),
  FOREIGN KEY (`country_code`) REFERENCES `country_name`(`code`) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`indicator_id`) REFERENCES `indicator_name`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request_log`
--

CREATE TABLE IF NOT EXISTS `request_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) NOT NULL,
  `request` varchar(255) NOT NULL,
  `requested_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=0;
