--
-- Setup of the database version table
--
-- Nathanael Tombs
-- 2/14/2015
-- 10:01 PM
--

-- --------------------------------------------------------

--
-- Table structure for table `versions`
--

CREATE TABLE IF NOT EXISTS `version` (
  `key` varchar(16) NOT NULL,
  `value` float NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;